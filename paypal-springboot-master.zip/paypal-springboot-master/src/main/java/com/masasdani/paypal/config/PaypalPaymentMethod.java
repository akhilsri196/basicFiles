package com.masasdani.paypal.config;

public enum PaypalPaymentMethod {

	credit_card, paypal
	
}
