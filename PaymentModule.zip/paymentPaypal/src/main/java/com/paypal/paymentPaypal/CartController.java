package com.paypal.paymentPaypal;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.paypal.paymentPaypal.bean.Product;
import com.paypal.paymentPaypal.service.PayPalService;
import com.paypal.paymentPaypal.setup.PayPalResult;
import com.paypal.paymentPaypal.setup.PayPalSucess;

@Controller
@RequestMapping("cart")
public class CartController {

	@Autowired
	private PayPalService payPalService;
	
	
	@RequestMapping(method=RequestMethod.GET)
	public String index(ModelMap modelMap)
	{
		List<Product> products=new ArrayList<Product>();
		products.add(new Product("p01","name1",2,3));
		products.add(new Product("p02","name2",4,2));
		products.add(new Product("p03","name3",5,4));
		modelMap.put("products",products);
		modelMap.put("payPalConfig",payPalService.getPayPalConfig());
		return "cart/index";
	}
	@RequestMapping(value="success",method=RequestMethod.GET)
	public String success(HttpServletRequest request)
	{
		PayPalSucess payPalSucess=new PayPalSucess();
		PayPalResult payPalResult=payPalSucess.getPayPal(request, payPalService.getPayPalConfig());
		System.out.println("Order");
		
		System.out.println(payPalResult.getFirst_name());
		
		System.out.println(payPalResult.getLast_name());
		
		return "cart/success";
	}
	
}
