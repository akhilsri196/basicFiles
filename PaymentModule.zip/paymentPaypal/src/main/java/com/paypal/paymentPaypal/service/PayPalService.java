package com.paypal.paymentPaypal.service;

import com.paypal.paymentPaypal.setup.PayPalConfig;

public interface PayPalService {

	public PayPalConfig getPayPalConfig();
}
