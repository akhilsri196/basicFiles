package com.product.MPTExam.Repository;

import java.util.List;

import com.product.MPTExam.DTO.ProductDTO;

public interface IProductRepo {
	
	public ProductDTO create(ProductDTO product);
	public ProductDTO update(String id,ProductDTO product);
	public ProductDTO delete(String id);
	public List<ProductDTO> viewProducts();
	public ProductDTO findProduct(String id);
}