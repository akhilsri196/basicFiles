package com.product.MPTExam;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.product.MPTExam.DTO.ProductDTO;
import com.product.MPTExam.Exceptions.IDNotFoundException;
import com.product.MPTExam.Service.IProductService;

@RestController
@RequestMapping("/products" )
public class ProductController {

	@Autowired
	IProductService serRef;

	@RequestMapping(method = RequestMethod.GET) 
	public List<ProductDTO> list() {
		return serRef.viewProducts();
	}

	@RequestMapping(method = RequestMethod.POST) 
	public ProductDTO create(@RequestBody ProductDTO product) {
		return serRef.create(product);
	}

	@RequestMapping(method = RequestMethod.PUT, value = "/{id}")  
	public ProductDTO update(@RequestBody ProductDTO product, @PathVariable(name = "id") String id) {
		return serRef.update(id, product);
	}

	@RequestMapping(method = RequestMethod.DELETE, value = "/{id}") 
	public ProductDTO delete(@PathVariable(name = "id") String id) {
		return serRef.delete(id);
	}

	@RequestMapping(method = RequestMethod.GET, value = "/{id}") 
	public ProductDTO findBy(@PathVariable(name = "id") String id) {
		return serRef.findProduct(id);
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND,reason=" Invalid ID")
    @ExceptionHandler({IDNotFoundException.class})
    public void HandleIDNotPresent()   
    {
    	
    }
	
}
