package com.product.MPTExam.Exceptions;

public class IDNotFoundException extends RuntimeException {
}
