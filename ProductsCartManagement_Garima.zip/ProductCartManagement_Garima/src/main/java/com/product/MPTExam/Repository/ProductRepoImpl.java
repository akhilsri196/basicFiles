package com.product.MPTExam.Repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.product.MPTExam.DTO.ProductDTO;
import com.product.MPTExam.Exceptions.IDNotFoundException;

@Repository
@Transactional
public class ProductRepoImpl implements IProductRepo { 

	@PersistenceContext
	EntityManager em;

	@Transactional
	@Override
	public ProductDTO create(ProductDTO product) {

		ProductDTO p = em.find(ProductDTO.class, product.getId());
			em.persist(product);
			return product;
	}

	@Override
	public ProductDTO update(String id, ProductDTO product) {
		em.merge(product);
		return product;
	}

	@Override
	public ProductDTO delete(String id) {

		ProductDTO p = em.find(ProductDTO.class, id);
		if (p != null) {
			em.remove(p);
			return p;
		}
		throw new IDNotFoundException();
	}

	@Override
	public List<ProductDTO> viewProducts() {
		Query query = em.createQuery("select p from ProductDTO p");
		return query.getResultList();
	}

	@Override
	public ProductDTO findProduct(String id) {

		ProductDTO p =  em.find(ProductDTO.class, id);
		if (p != null)
			return p;
		throw new IDNotFoundException();
	}

}
