package com.product.MPTExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MptExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(MptExamApplication.class, args);
	}

}
